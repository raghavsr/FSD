package com.fsdtraining.taskmanager.dao.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fsdtraining.taskmanager.dao.RepositoryDao;
import com.fsdtraining.taskmanager.entity.ParentEntity;

@Repository
public class RepositoryDaoImpl implements RepositoryDao {
	
	  @Autowired
	    private JdbcTemplate jdbcTemplate;
	  
	    @Override
	    public List<ParentEntity> viewProject() {
	        return jdbcTemplate.query(
	                "select p.project_id, \r\n" + 
	                "p.projectname, trunc(p.start_date) as start_date, trunc(p.end_date) as end_date, p.priority,\r\n" + 
	                "t.status,count(t.status) as status_count from task_table t inner join project_table p \r\n" + 
	                "on t.PROJECT_ID=p.PROJECT_ID group by p.project_id, \r\n" + 
	                "p.projectname, trunc(p.start_date), trunc(p.end_date), p.priority,\r\n" + 
	                "t.status",
	                (rs, rowNum) ->
	                        new ParentEntity(
	                                rs.getLong("project_id"),
	                                rs.getString("projectname"),
	                                rs.getTimestamp("start_date"),
	                                rs.getTimestamp("end_date"),
	                                rs.getBigDecimal("priority"),
	                                rs.getString("status"),
	                                rs.getLong("status_count")
	                        )
	        );
	    }

}
