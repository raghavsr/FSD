package com.fsdtraining.taskmanager.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsdtraining.taskmanager.dao.ParentTaskDao;
import com.fsdtraining.taskmanager.entity.ParentTaskEntity;
import com.fsdtraining.taskmanager.service.ParentTaskService;

@Service
public class ParentTaskServiceImpl implements ParentTaskService {

	@Autowired
	private ParentTaskDao parentTaskDao;

	@Override
	public List<ParentTaskEntity> getAll() {
		return this.parentTaskDao.findAll();
	}

	@Override
	public ParentTaskEntity getByID(Long id) {
		Optional<ParentTaskEntity> parentTask = this.parentTaskDao.findById(id);
		ParentTaskEntity parentTaskEntity = null;

		if (parentTask.isPresent()) {
			parentTaskEntity = parentTask.get();
		} 
		
		return parentTaskEntity;
	}

	@Override
	public boolean add(ParentTaskEntity parentTaskEntity) {
		this.parentTaskDao.save(parentTaskEntity);
		return true;
	}

	@Override
	public boolean update(ParentTaskEntity parentTaskEntity) {
		this.parentTaskDao.save(parentTaskEntity);
		return true;
	}

	@Override
	public boolean delete(Long id) {
		this.parentTaskDao.deleteById(id);
		return true;
	}

}
