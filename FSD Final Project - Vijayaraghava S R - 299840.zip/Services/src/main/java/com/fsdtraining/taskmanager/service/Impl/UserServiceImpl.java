package com.fsdtraining.taskmanager.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsdtraining.taskmanager.dao.UserDao;
import com.fsdtraining.taskmanager.entity.UserEntity;
import com.fsdtraining.taskmanager.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Override
	public List<UserEntity> getAll() {
		return this.userDao.findAll();
		}

	@Override
	public UserEntity getByID(Long id) {
		Optional<UserEntity> result = this.userDao.findById(id);
		UserEntity userEntity = null;
		
		if (result.isPresent()) {
			userEntity = result.get();
		} 
		return userEntity;
	}

	@Override
	public boolean add(UserEntity userEntity) {
		this.userDao.save(userEntity);
		return true;
	}

	@Override
	public boolean update(UserEntity userEntity) {
		this.userDao.save(userEntity);
		return true;
	}

	@Override
	public boolean delete(Long id) {
		this.userDao.deleteById(id);
		return true;
	}

}
