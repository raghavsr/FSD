package com.fsdtraining.taskmanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsdtraining.taskmanager.entity.ParentEntity;
import com.fsdtraining.taskmanager.service.ProjectService;

/**
 * 
 * Controller to handle Projects
 * 
 */

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
@RestController
@RequestMapping("/fsd")
public class ProjectController {

	@Autowired
	private ProjectService projectService;

	@GetMapping("/listallprojects")
	public List<ParentEntity> getProjects() {

		List<ParentEntity> listProjects = this.projectService.getAll();
		return listProjects;
		
	}

	@GetMapping("/projects/{projectid}")
	public ParentEntity getProjectsWithId(@PathVariable Long projectid) {

		ParentEntity project = this.projectService.getByID(projectid);
		return project;
		
	}

	
	@PostMapping(path ="/addproject" , consumes = "application/json", produces = "application/json")
	public ParentEntity addProject(@RequestBody ParentEntity project) {
		
		this.projectService.add(project);
		return project;
		
	}

	@PutMapping("/updateproject")
	public ParentEntity updateProject(@RequestBody ParentEntity project) {

		this.projectService.update(project);
		return project;
		
	}

	@PutMapping("/deleteproject/{projectid}")
	public ParentEntity deleteProjects(@PathVariable Long projectid) {

		ParentEntity project = this.projectService.getByID(projectid);
		this.projectService.delete(projectid);
		return project;
		
	}
	
	@GetMapping("/listprojects")
	public List<ParentEntity> projectlist() {
		
		List<ParentEntity> listProjects = this.projectService.listProjects();
		return listProjects;

	}
}
