package com.fsdtraining.taskmanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsdtraining.taskmanager.entity.UserEntity;
import com.fsdtraining.taskmanager.service.UserService;

/**
 * 
 * Controller to handle Users
 * 
 */

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
@RestController
@RequestMapping("/fsd")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/listallusers")
	public List<UserEntity> getUsers() {

		List<UserEntity> listUsers = this.userService.getAll();
		return listUsers;
		
	}

	@GetMapping("/users/{userid}")
	public UserEntity getUsersWithId(@PathVariable Long userid) {

		UserEntity user = this.userService.getByID(userid);
		return user;
		
	}
	
	@PostMapping(path = "/adduser", consumes = "application/json", produces = "application/json")
	public UserEntity addUser(@RequestBody UserEntity user) {
		
		this.userService.add(user);
		return user;
		
	}

	@PutMapping("/updateuser")
	public UserEntity updateUser(@RequestBody UserEntity user) {

		this.userService.update(user);
		return user;
		
	}

	@PutMapping("/deleteuser/{userid}")
	public UserEntity deleteUser(@PathVariable Long userid) {

		UserEntity user = this.userService.getByID(userid);
		return user;
		
	}
}
