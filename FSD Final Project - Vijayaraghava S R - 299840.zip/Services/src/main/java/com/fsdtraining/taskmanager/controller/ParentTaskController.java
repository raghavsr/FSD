package com.fsdtraining.taskmanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fsdtraining.taskmanager.entity.ParentTaskEntity;
import com.fsdtraining.taskmanager.service.ParentTaskService;

/**
 * 
 * Controller to handle Parent Tasks
 * 
 */

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
@RestController
@RequestMapping("/fsd")
public class ParentTaskController {

	@Autowired
	private ParentTaskService parentTaskService;

	@GetMapping("/parenttasks")
	public List<ParentTaskEntity> getAllParentTasks() {

		List<ParentTaskEntity> listParentAllTasks = this.parentTaskService.getAll();
		return listParentAllTasks;
		
	}

	@GetMapping("/parenttask/{taskid}")
	public ParentTaskEntity getParentTaskWithId(@PathVariable Long taskid) {

		ParentTaskEntity parenttask = this.parentTaskService.getByID(taskid);
		
		return parenttask;
	}

	@PostMapping("/addparenttask")
	public ParentTaskEntity addParentTask(@RequestBody ParentTaskEntity parenttaskentity) {

		if (!this.parentTaskService.add(parenttaskentity)) {
			throw new RuntimeException("Exception adding ParentTask");
		}

		return parenttaskentity;
	}

	@PutMapping("/updateparenttask")
	public ParentTaskEntity updateParentTask(@RequestBody ParentTaskEntity parenttaskentity) {

		if (!this.parentTaskService.update(parenttaskentity)) {
			throw new RuntimeException("Exception Updating ParentTask");
		}

		return parenttaskentity;
	}

	@PutMapping("/deleteparenttask/{taskid}")
	public ParentTaskEntity deleteParentTask(@PathVariable Long taskid) {

		ParentTaskEntity parenttask = this.parentTaskService.getByID(taskid);
		this.parentTaskService.delete(taskid);

		return parenttask;
	}
}
