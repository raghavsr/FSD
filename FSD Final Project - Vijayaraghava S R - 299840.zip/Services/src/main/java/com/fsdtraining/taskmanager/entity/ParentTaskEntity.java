package com.fsdtraining.taskmanager.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity class to persist parent tasks
 *
 */

@Entity
@Table(name="ParentTaskTable")
public class ParentTaskEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PARENT_ID")
	private long parentID;

	@Column(name="PARENT_TASK")
	private String parentTask;

	public ParentTaskEntity(long parentID, String parentTask) {
		this.parentID = parentID;
		this.parentTask = parentTask;
	}

	public ParentTaskEntity() {
		
	}
	
	public long getParentID() {
		return parentID;
	}

	public void setParentID(long parentID) {
		this.parentID = parentID;
	}

	public String getParentTask() {
		return parentTask;
	}

	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
}