package com.fsdtraining.taskmanager.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import java.sql.Timestamp;

/**
 * Entity class to persist User
 *
 */

@Entity
@Table(name="UserTable")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public UserEntity(String userId, Timestamp createdDate, long employeeId, String firstName, String lastName) {
		super();
		this.userId = userId;
		this.createdDate = createdDate;
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public UserEntity() {
	}

	@Id
	@Column(name="EMPLOYEE_ID")
	@JsonProperty
	private long employeeId;
	
	@Column(name="USER_ID")
	@JsonProperty
	private String userId;

	@Column(name="CREATED_DATE")
	@JsonProperty
	private Timestamp createdDate;


	@Column(name="FIRST_NAME")
	@JsonProperty
	private String firstName;

	@Column(name="LAST_NAME")
	@JsonProperty
	private String lastName;
	
	@Column(name="PROJECT_ID")
	@JsonProperty
	private long projectId;
	
	@Column(name="TASK_ID")
	@JsonProperty
	private long taskId;

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public long getEmployeeId() {
		return this.employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public long getProjectId() {
		return projectId;
	}


	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}


	public long getTaskId() {
		return taskId;
	}


	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}

}