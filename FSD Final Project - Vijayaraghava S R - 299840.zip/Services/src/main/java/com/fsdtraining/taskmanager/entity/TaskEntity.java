package com.fsdtraining.taskmanager.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * Entity class to persist Task
 *
 */

@Entity
@Table(name="TaskTable")
///@NamedQuery(name="TaskTable.findAll", query="SELECT t FROM TaskTable t")
public class TaskEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public TaskEntity(long taskId, Timestamp endDate, BigDecimal priority, Timestamp startDate, String status,
			String task) {
		super();
		this.taskId = taskId;
		this.endDate = endDate;
		this.priority = priority;
		this.startDate = startDate;
		this.status = status;
		this.task = task;
	}

	public TaskEntity() {
	}
	
	@Id
	@Column(name="TASK_ID")
	private long taskId;

	@Column(name="TASK")
	private String task;

	@Column(name="START_DATE")
	private Timestamp startDate;
	
	@Column(name="END_DATE")
	private Timestamp endDate;

	@Column(name="PRIORITY")
	private BigDecimal priority;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="PROJECT_ID")
	private long projectId;
	
	@Column(name="PARENT_ID")
	private long parentId;
	
	public long getTaskId() {
		return this.taskId;
	}

	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}

	public Timestamp getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getPriority() {
		return this.priority;
	}

	public void setPriority(BigDecimal priority) {
		this.priority = priority;
	}

	public Timestamp getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTask() {
		return this.task;
	}

	public void setTask(String task) {
		this.task = task;
	}


	public long getProjectId() {
		return projectId;
	}


	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}


	public long getParentId() {
		return parentId;
	}


	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

}