package com.fsdtraining.taskmanager.service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsdtraining.taskmanager.dao.TaskDao;
import com.fsdtraining.taskmanager.entity.TaskEntity;
import com.fsdtraining.taskmanager.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	private TaskDao taskDao;

	@Override
	public List<TaskEntity> getAll() {
		return this.taskDao.findAll();
	}

	@Override
	public TaskEntity getByID(Long id) {
		Optional<TaskEntity> result = this.taskDao.findById(id);
		TaskEntity taskEntity = null;

		if (result.isPresent()) {
			taskEntity = result.get();
		} 
		
		return taskEntity;
	}

	@Override
	public boolean add(TaskEntity taskEntity) {
		this.taskDao.save(taskEntity);
		return true;
	}

	@Override
	public boolean update(TaskEntity taskEntity) {
		this.taskDao.save(taskEntity);
		return true;
	}

	@Override
	public boolean delete(Long id) {
		this.taskDao.deleteById(id);
		return true;
	}

}
