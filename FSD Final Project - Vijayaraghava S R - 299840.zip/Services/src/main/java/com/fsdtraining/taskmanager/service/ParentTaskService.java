package com.fsdtraining.taskmanager.service;

import java.util.List;

import com.fsdtraining.taskmanager.entity.ParentTaskEntity;

public interface ParentTaskService {

	List<ParentTaskEntity> getAll();
	ParentTaskEntity getByID(Long id);
	boolean add(ParentTaskEntity s);
	boolean update(ParentTaskEntity s);
	boolean delete(Long id);

}
