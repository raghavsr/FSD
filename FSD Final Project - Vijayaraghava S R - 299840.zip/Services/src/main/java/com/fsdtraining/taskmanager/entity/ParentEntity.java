package com.fsdtraining.taskmanager.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

/**
 * Entity class to persist Projects
 *
 */

@Entity
@Table(name="ProjectTable")
public class ParentEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PROJECT_ID")
	private long projectId;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="END_DATE")
	private Timestamp endDate;

	@Column(name="PRIORITY")
	private BigDecimal priority;
	
	@Column(name="PROJECTNAME")
	private String projectname;

	@Column(name="START_DATE")
	private Timestamp startDate;
	
	private Long numOfTask;
	private Long numOfCompletedTask;
	private String taskStatus;
	private Long statusCount;

	public Long getStatusCount() {
		return statusCount;
	}

	public void setStatusCount(Long statusCount) {
		this.statusCount = statusCount;
	}

	public ParentEntity() {
	}

	public long getProjectId() {
		return this.projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public BigDecimal getPriority() {
		return this.priority;
	}

	public void setPriority(BigDecimal priority) {
		this.priority = priority;
	}

	public String getProjectname() {
		return this.projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}

	public Timestamp getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Long getNumOfCompletedTask() {
		return numOfCompletedTask;
	}

	public void setNumOfCompletedTask(Long numOfCompletedTask) {
		this.numOfCompletedTask = numOfCompletedTask;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Long getNumOfTask() {
		return numOfTask;
	}

	public void setNumOfTask(Long numOfTask) {
		this.numOfTask = numOfTask;
	}

	public ParentEntity(long projectId, Timestamp createdDate, Timestamp endDate, BigDecimal priority,
			String projectname, Timestamp startDate) {
		super();
		this.projectId = projectId;
		this.createdDate = createdDate;
		this.endDate = endDate;
		this.priority = priority;
		this.projectname = projectname;
		this.startDate = startDate;
	}

	public ParentEntity(long projectId, String projectname, Timestamp startDate, Timestamp endDate, BigDecimal priority, String taskStatus, Long statusCount
			 ) {
		super();
		this.projectId = projectId;
		this.projectname = projectname;
		this.startDate = startDate;
		this.endDate = endDate;
		this.priority = priority;
		this.taskStatus = taskStatus;
		this.statusCount = statusCount;
		
	}
}