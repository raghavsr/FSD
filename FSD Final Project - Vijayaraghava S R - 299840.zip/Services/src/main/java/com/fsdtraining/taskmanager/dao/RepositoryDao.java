package com.fsdtraining.taskmanager.dao;

import java.util.List;

import com.fsdtraining.taskmanager.entity.ParentEntity;

public interface RepositoryDao {
	List<ParentEntity> viewProject() ;
}
