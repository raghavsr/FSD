package com.fsdtraining.taskmanager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsdtraining.taskmanager.entity.TaskEntity;

public interface TaskDao extends JpaRepository<TaskEntity, Long>{

}
