package com.fsdtraining.taskmanager.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestWrapper {
	
	private List<TaskEntity> taskTable;
	private List<UserEntity> userTable;
	
	
	private List<ParentEntity> projectTable;
	
	private List<ParentTaskEntity> parenttaskTable;

	public List<TaskEntity> getTaskTable() {
		return taskTable;
	}

	public void setTaskTable(List<TaskEntity> taskTable) {
		this.taskTable = taskTable;
	}

	public List<UserEntity> getUserTable() {
		return userTable;
	}

	public void setUserTable(List<UserEntity> userTable) {
		this.userTable = userTable;
	}

	public List<ParentEntity> getProjectTable() {
		return projectTable;
	}

	public void setProjectTable(List<ParentEntity> projectTable) {
		this.projectTable = projectTable;
	}

	public List<ParentTaskEntity> getParenttaskTable() {
		return parenttaskTable;
	}

	public void setParenttaskTable(List<ParentTaskEntity> parenttaskTable) {
		this.parenttaskTable = parenttaskTable;
	}

	
	

}
