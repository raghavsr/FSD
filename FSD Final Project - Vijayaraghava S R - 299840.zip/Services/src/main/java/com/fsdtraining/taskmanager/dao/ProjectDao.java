package com.fsdtraining.taskmanager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsdtraining.taskmanager.entity.ParentEntity;

public interface ProjectDao  extends JpaRepository<ParentEntity, Long>{

}
