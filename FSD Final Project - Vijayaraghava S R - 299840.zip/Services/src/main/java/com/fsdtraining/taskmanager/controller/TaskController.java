package com.fsdtraining.taskmanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fsdtraining.taskmanager.entity.TaskEntity;
import com.fsdtraining.taskmanager.service.TaskService;

/**
 * 
 * Controller to handle Tasks
 * 
 */

@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
@RestController
@RequestMapping("/fsd")
public class TaskController {

	@Autowired
	private TaskService taskService;

	@GetMapping("/listalltasks")
	public List<TaskEntity> getTasks() {

		List<TaskEntity> listTasks = this.taskService.getAll();
		return listTasks;
		
	}

	@GetMapping("/gettask/{taskid}")
	public TaskEntity getTasksWithId(@PathVariable Long taskid) {

		TaskEntity task = this.taskService.getByID(taskid);
		return task;
		
	}

	@PostMapping(path ="/addtask" , consumes = "application/json", produces = "application/json")
	public TaskEntity addTasks(@RequestBody TaskEntity task) {

		this.taskService.add(task);
		return task;
		
	}

	@PutMapping("/updatetask")
	public TaskEntity updateTasks(@RequestBody TaskEntity task) {

		this.taskService.update(task);
		return task;
		
	}

	@PutMapping("/deletetask/{taskid}")
	public TaskEntity deleteTasks(@PathVariable Long taskid) {

		TaskEntity task = this.taskService.getByID(taskid);
		this.taskService.delete(taskid);
		return task;
		
	}
}
