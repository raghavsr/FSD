package com.fsdtraining.taskmanager.service;

import java.util.List;

import com.fsdtraining.taskmanager.entity.UserEntity;

public interface UserService {

	List<UserEntity> getAll();

	UserEntity getByID(Long id);

	boolean add(UserEntity s);

	boolean update(UserEntity s);

	boolean delete(Long id);
}
