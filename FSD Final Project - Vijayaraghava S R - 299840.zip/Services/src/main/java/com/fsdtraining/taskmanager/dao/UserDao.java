package com.fsdtraining.taskmanager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsdtraining.taskmanager.entity.UserEntity;

public interface UserDao extends JpaRepository<UserEntity, Long>{

}
