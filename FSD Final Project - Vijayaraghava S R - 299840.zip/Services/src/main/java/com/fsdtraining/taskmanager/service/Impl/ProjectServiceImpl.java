package com.fsdtraining.taskmanager.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsdtraining.taskmanager.dao.ProjectDao;
import com.fsdtraining.taskmanager.dao.RepositoryDao;
import com.fsdtraining.taskmanager.entity.ParentEntity;
import com.fsdtraining.taskmanager.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectDao projectDao;
	
	@Autowired
	private RepositoryDao repositoDao;

	@Override
	public List<ParentEntity> getAll() {
		return this.projectDao.findAll();
	}

	@Override
	public ParentEntity getByID(Long id) {
		Optional<ParentEntity> project = this.projectDao.findById(id);
		ParentEntity parentEntity = null;

		if (project.isPresent()) {
			parentEntity = project.get();
		} 
		return parentEntity;
	}

	@Override
	public boolean add(ParentEntity parentEntity) {
		this.projectDao.save(parentEntity);
		return true;
	}

	@Override
	public boolean update(ParentEntity parentEntity) {
		this.projectDao.save(parentEntity);
		return true;
	}

	@Override
	public boolean delete(Long id) {
		this.projectDao.deleteById(id);
		return true;
	}
	
	public List<ParentEntity> listProjects() {
		List<ParentEntity> lstViewProj = repositoDao.viewProject();
		Map<Long, ParentEntity> projTableMap = new HashMap<Long, ParentEntity>();

		for (ParentEntity pTable : lstViewProj) {
			if (projTableMap.containsKey(pTable.getProjectId())) {
				ParentEntity pTableObj = projTableMap.get(pTable.getProjectId());
				projTableMap.get(pTable.getProjectId())
						.setNumOfTask(pTableObj.getNumOfTask() + pTable.getStatusCount());
				if (pTable.getTaskStatus().equals("Completed")) {
					projTableMap.get(pTable.getProjectId()).setNumOfCompletedTask(pTable.getStatusCount());
				}

			} else {
				if (pTable.getTaskStatus().equals("Completed")) {
					pTable.setNumOfCompletedTask(pTable.getStatusCount());
				} else {
					pTable.setNumOfCompletedTask((long) 0);
				}
				pTable.setNumOfTask(pTable.getStatusCount());
				projTableMap.put(pTable.getProjectId(), pTable);
			}

		}
		List<ParentEntity> result2 = new ArrayList(projTableMap.values());

		return result2;

	}

}
