package com.fsdtraining.taskmanager.service;

import java.util.List;

import com.fsdtraining.taskmanager.entity.ParentEntity;

public interface ProjectService {

	List<ParentEntity> getAll();

	ParentEntity getByID(Long id);

	boolean add(ParentEntity s);

	boolean update(ParentEntity s);

	boolean delete(Long id);
	
	List<ParentEntity> listProjects();

}
