package com.fsdtraining.taskmanager.service;

import java.util.List;

import com.fsdtraining.taskmanager.entity.TaskEntity;

public interface TaskService {

	List<TaskEntity> getAll();

	TaskEntity getByID(Long id);

	boolean add(TaskEntity s);

	boolean update(TaskEntity s);

	boolean delete(Long id);
}
